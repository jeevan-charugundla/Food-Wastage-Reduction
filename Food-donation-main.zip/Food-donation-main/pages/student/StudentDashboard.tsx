import React, { useEffect, useState } from 'react';
import Layout from '../../components/Layout';
import { Card } from '../../components/Card';
import { useAuth } from '../../context/AuthContext';
import { getStudentDayConfirmations, setStudentConfirmation, getStudentImpact, getStudentVote, castVote, getDailyMenu, getActivePoll, votePoll } from '../../services/api';
import { MealType, MealStatus, StudentConfirmation, StudentImpact, VoteOption, StudentVote, DailyMenu, Poll } from '../../types';
import { Clock, CheckCircle, XCircle, AlertTriangle, Utensils, ThumbsUp, ThumbsDown, HelpCircle as MaybeIcon, Vote, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const StudentDashboard: React.FC = () => {
  const { user } = useAuth();
  const [meals, setMeals] = useState<StudentConfirmation[]>([]);
  const [impact, setImpact] = useState<StudentImpact | null>(null);
  const [activeMealType, setActiveMealType] = useState<MealType | null>(null);
  
  // Vote State
  const [currentVote, setCurrentVote] = useState<StudentVote | null>(null);
  const [voteLoading, setVoteLoading] = useState(false);
  
  // Menu State
  const [menu, setMenu] = useState<DailyMenu | null>(null);

  // Poll State
  const [communityPoll, setCommunityPoll] = useState<Poll | null>(null);
  const [pollUserVote, setPollUserVote] = useState<string | null>(null);
  const [pollLoading, setPollLoading] = useState(false);

  const today = new Date().toISOString().split('T')[0];
  const todayDisplay = new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });

  // Cutoff Times (24h format)
  const CUTOFFS = {
    [MealType.BREAKFAST]: 7.5, // 7:30 AM
    [MealType.LUNCH]: 10.5,    // 10:30 AM
    [MealType.DINNER]: 18.5    // 6:30 PM
  };

  const VOTE_CUTOFF = 10.5;

  const getCurrentHour = () => {
    const now = new Date();
    return now.getHours() + now.getMinutes() / 60;
  };

  const isCutoffPassed = (mealType: MealType) => getCurrentHour() > CUTOFFS[mealType];
  const isVoteCutoffPassed = () => getCurrentHour() > VOTE_CUTOFF;

  useEffect(() => {
    if (user) loadData();
  }, [user]);

  useEffect(() => {
    if (meals.length > 0 && activeMealType === null) {
      const firstPending = meals.find(m => m.status === MealStatus.PENDING && !isCutoffPassed(m.meal_type));
      if (firstPending) setActiveMealType(firstPending.meal_type);
    }
  }, [meals, activeMealType]);

  const loadData = async () => {
    if (!user) return;
    try {
      const [todayMeals, impactData, voteData, menuData, pollData] = await Promise.all([
        getStudentDayConfirmations(user.id, today),
        getStudentImpact(user.id),
        getStudentVote(user.id, today),
        getDailyMenu(today),
        getActivePoll(user.id)
      ]);
      setMeals(todayMeals);
      setImpact(impactData);
      setCurrentVote(voteData);
      setMenu(menuData);
      if (pollData) {
        setCommunityPoll(pollData.poll);
        setPollUserVote(pollData.userVote);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleVoteSubmit = async (option: VoteOption) => {
    if (!user) return;
    setVoteLoading(true);
    try {
      const newVote = await castVote(user.id, today, option);
      setCurrentVote(newVote);
      setVoteLoading(false);
    } catch (e) {
      alert("Failed to cast vote");
      setVoteLoading(false);
    }
  };

  const handleCommunityPollVote = async (optionId: string) => {
    if (!user || !communityPoll) return;
    setPollLoading(true);
    try {
      await votePoll(communityPoll.id, user.id, optionId);
      setPollUserVote(optionId);
    } catch (e) {
      console.error(e);
      alert("Failed to submit poll vote");
    } finally {
      setPollLoading(false);
    }
  };

  const handleConfirm = async (mealType: MealType, status: MealStatus) => {
    if (!user) return;
    const originalMeals = [...meals];
    setMeals(prev => prev.map(m => m.meal_type === mealType ? { ...m, status } : m));
    try {
      await setStudentConfirmation(user.id, today, mealType, status);
      getStudentImpact(user.id).then(setImpact);
    } catch (e) {
      setMeals(originalMeals);
    }
  };

  const getMealIcon = (type: MealType) => {
    switch (type) {
      case MealType.BREAKFAST: return "🍳";
      case MealType.LUNCH: return "🍛";
      case MealType.DINNER: return "🌙";
    }
  };

  const activeMeal = meals.find(m => m.meal_type === activeMealType);
  const isActionable = activeMeal && !isCutoffPassed(activeMeal.meal_type);
  const voteLocked = isVoteCutoffPassed();

  return (
    <Layout title="My Meals">
      {/* Sticky Header */}
      <motion.div 
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="sticky top-0 z-20 bg-slate-50/90 backdrop-blur-md py-3 -mx-4 px-4 border-b border-slate-200 mb-6 flex justify-between items-center"
      >
         <span className="text-sm font-bold text-slate-700 uppercase tracking-wide">{todayDisplay}</span>
         {impact && impact.no_show_count > 0 && (
           <div className="flex items-center gap-1.5 bg-red-50 px-2 py-1 rounded-full border border-red-100">
             <AlertTriangle size={12} className="text-red-500" />
             <span className="text-xs font-bold text-red-600">{impact.no_show_count} Missed</span>
           </div>
         )}
      </motion.div>

      <div className="max-w-md mx-auto space-y-6 pb-24">
        {/* DAILY POLL CARD WITH MENU */}
        <Card className="bg-white border-emerald-100 shadow-sm" delay={0.1}>
          <div className="flex items-center gap-2 mb-4">
             <div className="p-2 bg-emerald-100 rounded-lg text-emerald-600">
                <Utensils size={18} />
             </div>
             <div>
               <h3 className="font-bold text-slate-900 leading-tight">Today's Menu & Poll</h3>
               <p className="text-xs text-slate-500 font-medium">
                 {voteLocked ? "Voting Closed" : "Check the menu and cast your vote"}
               </p>
             </div>
          </div>

          {/* MENU DISPLAY */}
          {menu && (
            <div className="bg-slate-50 rounded-xl p-4 mb-5 border border-slate-100 text-sm">
                <div className="mb-2 pb-2 border-b border-slate-200 border-dashed">
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Lunch</span>
                    <p className="text-slate-800 font-medium leading-snug">{menu.lunch}</p>
                </div>
                <div>
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Dinner</span>
                    <p className="text-slate-800 font-medium leading-snug">{menu.dinner}</p>
                </div>
            </div>
          )}

          {!currentVote && !voteLocked ? (
            <div className="space-y-2">
               {[
                 { opt: VoteOption.YES, label: "Yes, I'm eating", icon: ThumbsUp, color: "bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border-emerald-200" },
                 { opt: VoteOption.MAYBE, label: "Not Sure Yet", icon: MaybeIcon, color: "bg-orange-50 text-orange-700 hover:bg-orange-100 border-orange-200" },
                 { opt: VoteOption.NO, label: "No, Skipping", icon: ThumbsDown, color: "bg-slate-50 text-slate-700 hover:bg-slate-100 border-slate-200" },
               ].map((btn) => (
                 <motion.button
                   key={btn.opt}
                   whileTap={{ scale: 0.98 }}
                   onClick={() => handleVoteSubmit(btn.opt)}
                   disabled={voteLoading}
                   className={`w-full flex items-center gap-3 p-3 rounded-xl border text-sm font-bold transition-all ${btn.color}`}
                 >
                   <btn.icon size={16} />
                   {btn.label}
                   {voteLoading && <span className="ml-auto text-xs opacity-70">Saving...</span>}
                 </motion.button>
               ))}
            </div>
          ) : (
            <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 text-center">
               <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-3">
                  <CheckCircle size={24} />
               </div>
               <h4 className="font-bold text-slate-900">Vote Recorded</h4>
               <p className="text-xs text-slate-500 mt-1 mb-3">
                 You selected: <span className="font-bold text-slate-700">{currentVote?.vote === VoteOption.YES ? "Eating" : currentVote?.vote === VoteOption.NO ? "Skipping" : "Not Sure"}</span>
               </p>
               
               {!voteLocked && (
                 <button 
                   onClick={() => setCurrentVote(null)} 
                   className="text-xs font-bold text-emerald-600 hover:underline"
                 >
                   Change Vote
                 </button>
               )}
            </div>
          )}
        </Card>
        
        {/* NEW COMMUNITY POLL CARD */}
        {communityPoll && (
          <Card className="bg-white border-indigo-100 shadow-sm" delay={0.2}>
             <div className="flex items-center gap-2 mb-4">
                <div className="p-2 bg-indigo-100 rounded-lg text-indigo-600">
                   <Vote size={18} />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 leading-tight">Community Poll</h3>
                  <p className="text-xs text-slate-500 font-medium">Have your say in menu planning</p>
                </div>
             </div>
             
             <p className="font-medium text-slate-800 mb-4">{communityPoll.question}</p>
             
             {!pollUserVote ? (
               <div className="space-y-2">
                 {communityPoll.options.map(opt => (
                    <motion.button
                      key={opt.id}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => handleCommunityPollVote(opt.id)}
                      disabled={pollLoading}
                      className="w-full text-left p-3 rounded-xl border border-slate-200 text-sm font-medium hover:bg-slate-50 hover:border-indigo-300 transition-colors flex justify-between items-center group"
                    >
                       <span>{opt.label}</span>
                       <div className="h-4 w-4 rounded-full border-2 border-slate-300 group-hover:border-indigo-500" />
                    </motion.button>
                 ))}
                 {pollLoading && <div className="text-center text-xs text-slate-400 mt-2 flex items-center justify-center gap-1"><Loader2 className="animate-spin" size={12}/> Submitting...</div>}
               </div>
             ) : (
               <div className="bg-indigo-50 rounded-xl p-4 border border-indigo-100 text-center">
                  <div className="text-indigo-600 font-bold mb-1 flex items-center justify-center gap-2">
                    <CheckCircle size={16} /> Vote Submitted
                  </div>
                  <p className="text-xs text-slate-500">
                    Thanks for voting! Check back later for results.
                  </p>
               </div>
             )}
          </Card>
        )}

        {/* Meal List */}
        <div className="space-y-3">
          <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1">Today's Meals</h4>
          {meals.map((meal, idx) => {
            const locked = isCutoffPassed(meal.meal_type);
            const isActive = activeMealType === meal.meal_type;
            
            return (
              <Card 
                key={meal.meal_type} 
                delay={0.2 + (idx * 0.1)}
                onClick={() => !locked && setActiveMealType(meal.meal_type)}
                className={`transition-all duration-300 cursor-pointer border-l-4 ${
                  isActive ? 'border-l-emerald-500 ring-2 ring-emerald-500/10' : 'border-l-transparent hover:border-l-slate-300'
                } ${locked ? 'opacity-60 bg-slate-50' : ''}`}
              >
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-4">
                    <span className="text-2xl filter drop-shadow-sm">{getMealIcon(meal.meal_type)}</span>
                    <div>
                      <h3 className={`font-bold capitalize ${isActive ? 'text-emerald-900' : 'text-slate-900'}`}>
                        {meal.meal_type.toLowerCase()}
                      </h3>
                      <div className="text-xs flex items-center gap-1 font-medium text-slate-400">
                         {locked ? <span className="text-red-500 flex items-center gap-1"><Clock size={10} /> Passed</span> : <span>Open</span>}
                      </div>
                    </div>
                  </div>
                  
                  {meal.status !== MealStatus.PENDING ? (
                    <span className={`text-[10px] font-bold px-2 py-1 rounded-md border uppercase ${
                      meal.status === MealStatus.EATING ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 
                      meal.status === MealStatus.NOT_EATING ? 'bg-red-50 text-red-700 border-red-200' : 
                      'bg-orange-50 text-orange-700 border-orange-200'
                    }`}>
                      {meal.status.replace('_', ' ')}
                    </span>
                  ) : (
                    !locked && <div className="h-2 w-2 rounded-full bg-orange-500" />
                  )}
                </div>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Floating Action Bar */}
      <AnimatePresence>
      {isActionable && (
        <motion.div 
          initial={{ y: 100 }} animate={{ y: 0 }} exit={{ y: 100 }}
          className="fixed bottom-[84px] md:bottom-4 left-4 right-4 md:left-auto md:right-auto md:w-[400px] md:mx-auto z-30"
        >
          <div className="bg-white rounded-2xl shadow-xl shadow-slate-200/50 border border-slate-100 p-4">
             <div className="flex justify-between items-center mb-3 px-1">
                <span className="font-bold text-slate-900 capitalize flex items-center gap-2">
                  {getMealIcon(activeMeal!.meal_type)} {activeMeal!.meal_type.toLowerCase()}
                </span>
             </div>
             <div className="grid grid-cols-3 gap-3">
               {[
                 { status: MealStatus.EATING, label: 'Eating', icon: CheckCircle, color: 'bg-emerald-600 text-white', ring: 'ring-emerald-200' },
                 { status: MealStatus.LATE, label: 'Late', icon: Clock, color: 'bg-orange-500 text-white', ring: 'ring-orange-200' },
                 { status: MealStatus.NOT_EATING, label: 'Skip', icon: XCircle, color: 'bg-slate-200 text-slate-600 hover:bg-slate-300', ring: 'ring-slate-200' }
               ].map((action) => (
                 <motion.button
                    key={action.status}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => handleConfirm(activeMeal!.meal_type, action.status)}
                    className={`h-12 rounded-xl font-bold text-sm flex flex-col items-center justify-center gap-1 shadow-sm transition-all ${
                      activeMeal!.status === action.status ? `ring-2 ${action.ring} ${action.color}` : action.color
                    }`}
                  >
                    {action.label}
                  </motion.button>
               ))}
             </div>
          </div>
        </motion.div>
      )}
      </AnimatePresence>
    </Layout>
  );
};

export default StudentDashboard;