import React, { useEffect, useState } from 'react';
import Layout from '../../components/Layout';
import { Card } from '../../components/Card';
import { useAuth } from '../../context/AuthContext';
import { getStudentHistory } from '../../services/api';
import { StudentConfirmation, MealStatus, MealType } from '../../types';
import { Calendar, CheckCircle, XCircle, Clock, AlertCircle } from 'lucide-react';

const StudentHistory: React.FC = () => {
  const { user } = useAuth();
  const [history, setHistory] = useState<StudentConfirmation[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      getStudentHistory(user.id).then(data => {
        setHistory(data);
        setLoading(false);
      });
    }
  }, [user]);

  const formatDate = (dateStr: string) => {
    const d = new Date(dateStr);
    const today = new Date();
    if (d.toDateString() === today.toDateString()) return 'Today';
    return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
  };

  const getStatusColor = (status: MealStatus) => {
    switch (status) {
      case MealStatus.EATING: return 'bg-green-100 text-green-700';
      case MealStatus.NOT_EATING: return 'bg-red-100 text-red-700';
      case MealStatus.LATE: return 'bg-yellow-100 text-yellow-700';
      default: return 'bg-gray-100 text-gray-500';
    }
  };

  const getStatusIcon = (status: MealStatus) => {
    switch (status) {
      case MealStatus.EATING: return <CheckCircle size={16} />;
      case MealStatus.NOT_EATING: return <XCircle size={16} />;
      case MealStatus.LATE: return <Clock size={16} />;
      default: return <AlertCircle size={16} />;
    }
  };

  return (
    <Layout title="Meal History">
      <div className="max-w-md mx-auto space-y-4">
        {loading ? (
          <div className="text-center py-8 text-gray-500">Loading history...</div>
        ) : history.length === 0 ? (
          <Card className="text-center py-12">
            <div className="bg-gray-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <Calendar className="text-gray-400" size={32} />
            </div>
            <h3 className="text-lg font-medium text-gray-900">No History Yet</h3>
            <p className="text-gray-500 mt-1 text-sm">Your meal confirmations will appear here.</p>
          </Card>
        ) : (
          // Group by Date visually
          <div className="space-y-6">
            {Array.from(new Set(history.map(h => h.date))).map((date: string) => (
              <div key={date}>
                <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wide mb-2 ml-1">{formatDate(date)}</h4>
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden divide-y divide-gray-50">
                  {history.filter(h => h.date === date).map(item => (
                    <div key={item.id} className="p-4 flex items-center justify-between hover:bg-gray-50 transition">
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-full ${getStatusColor(item.status).replace('text-', 'bg-opacity-20 text-')}`}>
                           {getStatusIcon(item.status)}
                        </div>
                        <div>
                          <p className="font-bold text-gray-900 text-sm capitalize">{item.meal_type.toLowerCase()}</p>
                          <p className="text-xs text-gray-500">
                            {item.status === MealStatus.EATING ? 'Confirmed' : item.status === MealStatus.NOT_EATING ? 'Skipped' : 'Late Arrival'}
                          </p>
                        </div>
                      </div>
                      <div className={`px-2.5 py-1 rounded-md text-[10px] font-bold uppercase ${getStatusColor(item.status)}`}>
                        {item.status.replace('_', ' ')}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
};

export default StudentHistory;