import { db } from './mockDb';
import { AttendanceRecord, FoodStatus, Pickup, PickupStatus, PredictionResult, SurplusFood, User, UserRole, PredictionMode, AdvancedPredictionResult, StudentConfirmation, MealStatus, MealType, StudentImpact, VoteOption, StudentVote, NgoStats, NgoCapacity, DigitalReceipt, DailyMenu, Poll, PollVote } from '../types';
import { runPredictionAlgorithm } from './predictionEngine';

// Simulate API delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// --- AUTH ---
export const login = async (email: string): Promise<User> => {
  await delay(500);
  const users = db.getUsers();
  const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());
  if (!user) throw new Error("User not found");
  return user;
};

// --- ATTENDANCE PREDICTION ---
export const getPrediction = async (adminId: string): Promise<PredictionResult> => {
  await delay(600);
  const history = db.getAttendance().filter(a => a.admin_id === adminId);
  const last7Days = history.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 7);
  
  if (last7Days.length === 0) {
    return { predicted_count: 0, recommended_food_quantity: 0, is_weekend: false, average_last_7_days: 0 };
  }

  const sum = last7Days.reduce((acc, curr) => acc + curr.actual_count, 0);
  const avg = Math.round(sum / last7Days.length);
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const isWeekend = tomorrow.getDay() === 0 || tomorrow.getDay() === 6;

  // --- VOTE INTEGRATION ---
  const todayDate = new Date().toISOString().split('T')[0];
  const votes = db.getVotes().filter(v => v.date === todayDate);
  
  const voteSummary = {
    yes: votes.filter(v => v.vote === VoteOption.YES).length,
    no: votes.filter(v => v.vote === VoteOption.NO).length,
    maybe: votes.filter(v => v.vote === VoteOption.MAYBE).length,
    total: votes.length
  };

  // Formula: (Vote YES × 0.8) + (Vote MAYBE × 0.5)
  // We use the votes as the primary live signal for "Today/Tomorrow" prediction.
  
  let voteBasedPrediction = 0;
  if (votes.length > 0) {
    voteBasedPrediction = (voteSummary.yes * 0.8) + (voteSummary.maybe * 0.5) + (voteSummary.no * 0);
  }

  // Blending Logic:
  // If we have significant live data (voteBasedPrediction > 0), prioritize it.
  // Otherwise fall back to history avg.
  
  let finalPredicted = avg;
  
  // Force use of votes if available (Per requirements)
  // We treat the vote prediction as a signal for the upcoming main meal.
  if (voteSummary.total > 20) {
      finalPredicted = Math.round(voteBasedPrediction); 
  } else {
      // Historical fallback
      if (isWeekend) finalPredicted += Math.round(avg * 0.10);
  }

  return {
    predicted_count: finalPredicted,
    recommended_food_quantity: finalPredicted + 10, 
    is_weekend: isWeekend,
    average_last_7_days: avg,
    vote_summary: voteSummary
  };
};

export const runFullPrediction = async (
  adminId: string, 
  targetDate: string, 
  mode: PredictionMode, 
  isSpecialEvent: boolean
): Promise<AdvancedPredictionResult> => {
  await delay(800);
  const history = db.getAttendance().filter(a => a.admin_id === adminId);
  return runPredictionAlgorithm({
    history,
    targetDate,
    mode,
    isSpecialEvent
  });
};

export const getHistory = async (adminId: string): Promise<AttendanceRecord[]> => {
  await delay(300);
  return db.getAttendance().filter(a => a.admin_id === adminId).sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime());
};

// --- FOOD MANAGEMENT ---
export const addFood = async (food: Omit<SurplusFood, 'id' | 'status'>): Promise<SurplusFood> => {
  await delay(400);
  const foods = db.getFood();
  const newFood: SurplusFood = {
    ...food,
    id: foods.length > 0 ? Math.max(...foods.map(f => f.id)) + 1 : 1,
    status: FoodStatus.AVAILABLE
  };
  foods.push(newFood);
  db.saveFood(foods);
  return newFood;
};

export const getAvailableFood = async (): Promise<SurplusFood[]> => {
  await delay(400);
  const foods = db.getFood();
  const now = new Date();
  const users = db.getUsers();

  const updatedFoods = foods.map(f => {
    if (f.status === FoodStatus.AVAILABLE && new Date(f.expiry_time) < now) {
      return { ...f, status: FoodStatus.EXPIRED };
    }
    return f;
  });
  
  if (JSON.stringify(updatedFoods) !== JSON.stringify(foods)) {
    db.saveFood(updatedFoods);
  }

  return updatedFoods.map(f => {
    const admin = users.find(u => u.id === f.admin_id);
    return {
      ...f,
      admin_name: admin?.name,
      location: admin?.location,
      distance_km: Math.floor(Math.random() * 10) + 1 // Mock distance
    };
  }).sort((a, b) => new Date(b.expiry_time).getTime() - new Date(a.expiry_time).getTime());
};

export const getFoodForAdmin = async (adminId: string): Promise<SurplusFood[]> => {
  await delay(400);
  return (await getAvailableFood()).filter(f => f.admin_id === adminId);
};

// --- PICKUP ---
export const acceptPickup = async (foodId: number, ngoId: string): Promise<Pickup> => {
  await delay(400);
  const foods = db.getFood();
  const foodIndex = foods.findIndex(f => f.id === foodId);
  
  if (foodIndex === -1) throw new Error("Food not found");
  if (foods[foodIndex].status !== FoodStatus.AVAILABLE) throw new Error("Food not available");
  
  // Capacity Check
  const capacities = db.getNgoCapacity();
  const today = new Date().toISOString().split('T')[0];
  const cap = capacities.find(c => c.ngo_id === ngoId && c.date === today);
  
  if (cap) {
    if (cap.remaining_capacity < foods[foodIndex].quantity) {
      throw new Error("Insufficient NGO capacity for this food quantity.");
    }
    // Update Capacity
    cap.remaining_capacity -= foods[foodIndex].quantity;
    db.saveNgoCapacity(capacities);
  }

  foods[foodIndex].status = FoodStatus.ACCEPTED;
  db.saveFood(foods);

  const pickups = db.getPickups();
  const newPickup: Pickup = {
    id: pickups.length > 0 ? Math.max(...pickups.map(p => p.id)) + 1 : 1,
    food_id: foodId,
    ngo_id: ngoId,
    pickup_status: PickupStatus.PENDING
  };
  pickups.push(newPickup);
  db.savePickups(pickups);
  
  return newPickup;
};

export const declinePickup = async (foodId: number, ngoId: string, reason: string): Promise<void> => {
  await delay(300);
  // In a real app, we would log the decline reason and notify the next NGO logic here.
  // For MVP, we simply don't do anything to the food status (it remains AVAILABLE).
  console.log(`NGO ${ngoId} declined food ${foodId}. Reason: ${reason}. Auto-reassigning...`);
  return;
};

export const updatePickupStatus = async (pickupId: number, status: PickupStatus): Promise<Pickup> => {
  await delay(300);
  const pickups = db.getPickups();
  const index = pickups.findIndex(p => p.id === pickupId);
  if (index === -1) throw new Error("Pickup not found");
  
  pickups[index].pickup_status = status;
  db.savePickups(pickups);
  return pickups[index];
};

export const uploadPickupProof = async (pickupId: number, photoBase64: string): Promise<Pickup> => {
  await delay(1000); // Simulate upload time
  const pickups = db.getPickups();
  const index = pickups.findIndex(p => p.id === pickupId);
  if (index === -1) throw new Error("Pickup not found");

  const pickup = pickups[index];
  
  // Update Pickup Status
  pickup.proof_url = "https://via.placeholder.com/150"; // Mock upload
  pickup.proof_uploaded_at = new Date().toISOString();
  pickup.pickup_status = PickupStatus.DELIVERED;
  db.savePickups(pickups);

  // --- RECEIPT AUTO-GENERATION ---
  try {
    const existingReceipts = db.getReceipts();
    const alreadyExists = existingReceipts.find(r => r.pickup_id === pickupId);
    
    if (!alreadyExists) {
        const users = db.getUsers();
        const ngo = users.find(u => u.id === pickup.ngo_id);
        
        const allFoods = db.getFood();
        const food = allFoods.find(f => f.id === pickup.food_id);
        const donor = users.find(u => u.id === food?.admin_id);

        if (ngo && food && donor) {
            const dateStr = new Date().toISOString();
            // Format: NGO-YYYYMM-XXXX
            const yearMonth = dateStr.slice(0, 4) + dateStr.slice(5, 7);
            const randomSuffix = Math.floor(1000 + Math.random() * 9000);
            
            const newReceipt: DigitalReceipt = {
                id: `NGO-${yearMonth}-${randomSuffix}`,
                pickup_id: pickup.id,
                ngo_id: ngo.id,
                ngo_name: ngo.name,
                admin_id: donor.id,
                donor_name: donor.name,
                food_name: food.food_name,
                quantity: food.quantity,
                pickup_location: food.location || donor.location,
                pickup_time: dateStr,
                generated_at: dateStr,
                verification_status: 'VERIFIED'
            };
            
            const receipts = [...existingReceipts, newReceipt];
            db.saveReceipts(receipts);
        }
    }
  } catch (err) {
      console.error("Failed to generate receipt automatically", err);
  }
  
  return pickup;
};

export const getNgoPickups = async (ngoId: string): Promise<Pickup[]> => {
  await delay(300);
  const pickups = db.getPickups().filter(p => p.ngo_id === ngoId);
  const foods = await getAvailableFood();
  // We need to fetch accepted/picked foods too, getAvailableFood only returns AVAILABLE
  const allFoods = db.getFood();
  
  return pickups.map(p => ({
    ...p,
    food: allFoods.find(f => f.id === p.food_id)
  })).sort((a, b) => b.id - a.id);
};

export const getNgoReceipts = async (ngoId: string): Promise<DigitalReceipt[]> => {
    await delay(300);
    return db.getReceipts()
        .filter(r => r.ngo_id === ngoId)
        .sort((a, b) => new Date(b.generated_at).getTime() - new Date(a.generated_at).getTime());
};

// --- NGO DASHBOARD ---
export const getNgoStats = async (ngoId: string): Promise<NgoStats> => {
  await delay(400);
  const pickups = db.getPickups().filter(p => p.ngo_id === ngoId && p.pickup_status === PickupStatus.DELIVERED);
  const allFoods = db.getFood();
  
  const totalCollected = pickups.reduce((acc, p) => {
    const f = allFoods.find(food => food.id === p.food_id);
    return acc + (f ? f.quantity : 0);
  }, 0);

  const peopleFed = totalCollected; // 1 plate = 1 person approx
  const co2Saved = Math.round(totalCollected * 0.5); // 0.5kg per meal approx

  const today = new Date().toISOString().split('T')[0];
  let capacity = db.getNgoCapacity().find(c => c.ngo_id === ngoId && c.date === today);
  
  if (!capacity) {
    // Default capacity if not set
    capacity = {
      ngo_id: ngoId,
      date: today,
      max_capacity: 150,
      remaining_capacity: 150,
      volunteers_available: 5
    };
  }

  const reliability = db.getNgoReliability().find(r => true) || { score: 92, on_time_percentage: 95, missed_pickups: 1 }; // Default seed

  return {
    total_collected: totalCollected,
    people_fed: peopleFed,
    co2_saved: co2Saved,
    capacity,
    reliability
  };
};

export const updateNgoCapacity = async (ngoId: string, capacity: number, volunteers: number): Promise<NgoCapacity> => {
  await delay(300);
  const allCaps = db.getNgoCapacity();
  const today = new Date().toISOString().split('T')[0];
  const idx = allCaps.findIndex(c => c.ngo_id === ngoId && c.date === today);
  
  const newCap: NgoCapacity = {
    ngo_id: ngoId,
    date: today,
    max_capacity: capacity,
    remaining_capacity: capacity, // Resetting remaining when max changes? Simple logic for now.
    volunteers_available: volunteers
  };

  if (idx !== -1) {
    allCaps[idx] = { ...allCaps[idx], max_capacity: capacity, volunteers_available: volunteers }; // Keep remaining diff? Re-calc is complex. 
    // Simplified: update max, adjust remaining by diff
    const diff = capacity - allCaps[idx].max_capacity;
    allCaps[idx].remaining_capacity += diff;
    allCaps[idx].max_capacity = capacity;
    allCaps[idx].volunteers_available = volunteers;
  } else {
    allCaps.push(newCap);
  }
  
  db.saveNgoCapacity(allCaps);
  return idx !== -1 ? allCaps[idx] : newCap;
};

// ... existing admin methods ...

export const getAdminPickups = async (adminId: string): Promise<Pickup[]> => {
  await delay(300);
  const allPickups = db.getPickups();
  const foods = await getAvailableFood();
  const myFoods = foods.filter(f => f.admin_id === adminId);
  const myFoodIds = myFoods.map(f => f.id);
  
  return allPickups
    .filter(p => myFoodIds.includes(p.food_id))
    .map(p => ({
      ...p,
      food: myFoods.find(f => f.id === p.food_id)
    }))
    .sort((a, b) => b.id - a.id);
};

// --- STUDENT VOTING & POLLS ---

export const getStudentVote = async (studentId: string, date: string): Promise<StudentVote | null> => {
  await delay(200);
  const votes = db.getVotes();
  return votes.find(v => v.student_id === studentId && v.date === date) || null;
};

export const getDailyMenu = async (date: string): Promise<DailyMenu> => {
  await delay(200);
  const menus = db.getMenu();
  return menus.find(m => m.date === date) || {
     date,
     breakfast: "Bread, Jam, Milk, Tea",
     lunch: "Rice, Sambar, Potato Fry, Curd",
     dinner: "Rice, Rasam, Egg Curry / Banana"
  }; // Return default if not found
};

export const castVote = async (studentId: string, date: string, vote: VoteOption): Promise<StudentVote> => {
  await delay(200);
  const votes = db.getVotes();
  const existingIndex = votes.findIndex(v => v.student_id === studentId && v.date === date);
  
  const newVote: StudentVote = {
    id: existingIndex !== -1 ? votes[existingIndex].id : Date.now(),
    student_id: studentId,
    date,
    vote,
    voted_at: new Date().toISOString()
  };

  if (existingIndex !== -1) {
    votes[existingIndex] = newVote;
  } else {
    votes.push(newVote);
  }
  
  db.saveVotes(votes);
  return newVote;
};

// NEW: Community Polls
export const getActivePoll = async (studentId?: string): Promise<{ poll: Poll, userVote: string | null } | null> => {
  await delay(300);
  const polls = db.getPolls();
  const activePoll = polls.find(p => p.active);
  
  if (!activePoll) return null;
  
  let userVote = null;
  if (studentId) {
    const votes = db.getPollVotes();
    const vote = votes.find(v => v.poll_id === activePoll.id && v.student_id === studentId);
    if (vote) userVote = vote.option_id;
  }
  
  return { poll: activePoll, userVote };
};

export const votePoll = async (pollId: string, studentId: string, optionId: string): Promise<void> => {
  await delay(300);
  const polls = db.getPolls();
  const pollIndex = polls.findIndex(p => p.id === pollId);
  
  if (pollIndex === -1) throw new Error("Poll not found");
  
  // Update Vote Count
  const optionIndex = polls[pollIndex].options.findIndex(o => o.id === optionId);
  if (optionIndex !== -1) {
    polls[pollIndex].options[optionIndex].count += 1;
    db.savePolls(polls);
  }
  
  // Save User Vote Record
  const votes = db.getPollVotes();
  // Check if already voted (should be handled by UI, but double check)
  if (!votes.find(v => v.poll_id === pollId && v.student_id === studentId)) {
    votes.push({ poll_id: pollId, student_id: studentId, option_id: optionId });
    db.savePollVotes(votes);
  }
};

// NEW: Get aggregate votes for the day
export const getDailyVoteStats = async (): Promise<{ yes: number, no: number, maybe: number, total: number }> => {
  await delay(400); // Simulate network
  const todayDate = new Date().toISOString().split('T')[0];
  const votes = db.getVotes().filter(v => v.date === todayDate);
  
  return {
    yes: votes.filter(v => v.vote === VoteOption.YES).length,
    no: votes.filter(v => v.vote === VoteOption.NO).length,
    maybe: votes.filter(v => v.vote === VoteOption.MAYBE).length,
    total: votes.length
  };
};

// --- STUDENT CONFIRMATIONS & IMPACT ---

// Get all confirmations for a specific date
export const getStudentDayConfirmations = async (studentId: string, date: string): Promise<StudentConfirmation[]> => {
  await delay(300);
  const confs = db.getConfirmations();
  const dayConfs = confs.filter(c => c.student_id === studentId && c.date === date);
  
  // Ensure we return an object for each meal type, even if not yet in DB
  const meals = [MealType.BREAKFAST, MealType.LUNCH, MealType.DINNER];
  const result: StudentConfirmation[] = meals.map(meal => {
    const existing = dayConfs.find(c => c.meal_type === meal);
    if (existing) return existing;
    return {
      id: Math.random(), // Temporary ID until saved
      student_id: studentId,
      date,
      meal_type: meal,
      status: MealStatus.PENDING,
      timestamp: new Date().toISOString()
    };
  });
  
  return result;
};

export const setStudentConfirmation = async (
  studentId: string, 
  date: string, 
  mealType: MealType, 
  status: MealStatus
): Promise<StudentConfirmation> => {
  await delay(200); // Fast response
  const confs = db.getConfirmations();
  const existingIndex = confs.findIndex(c => c.student_id === studentId && c.date === date && c.meal_type === mealType);
  
  const newConf: StudentConfirmation = {
    id: existingIndex !== -1 ? confs[existingIndex].id : Date.now(),
    student_id: studentId,
    date,
    meal_type: mealType,
    status,
    timestamp: new Date().toISOString(),
    synced: true
  };

  if (existingIndex !== -1) {
    confs[existingIndex] = newConf;
  } else {
    confs.push(newConf);
  }
  
  db.saveConfirmations(confs);
  return newConf;
};

export const getStudentImpact = async (studentId: string): Promise<StudentImpact> => {
  await delay(400);
  const confs = db.getConfirmations().filter(c => c.student_id === studentId);
  const badges = db.getBadges();
  
  // Calculate impact
  const mealsSaved = confs.filter(c => c.status === MealStatus.NOT_EATING).length;
  // Mock no-show
  const noShowCount = 2; // Hardcoded from requirements for demo
  const streak = 12; // Hardcoded streak

  return {
    meals_saved: mealsSaved,
    streak_days: streak,
    no_show_count: noShowCount,
    badges: badges // Return seeded badges
  };
};

export const getStudentHistory = async (studentId: string): Promise<StudentConfirmation[]> => {
  await delay(300);
  const confs = db.getConfirmations().filter(c => c.student_id === studentId);
  return confs.sort((a, b) => {
    // Sort by date desc, then by meal type order (Dinner > Lunch > Breakfast)
    const dateDiff = new Date(b.date).getTime() - new Date(a.date).getTime();
    if (dateDiff !== 0) return dateDiff;
    
    const mealOrder = { [MealType.DINNER]: 3, [MealType.LUNCH]: 2, [MealType.BREAKFAST]: 1 };
    return (mealOrder[b.meal_type] || 0) - (mealOrder[a.meal_type] || 0);
  });
};