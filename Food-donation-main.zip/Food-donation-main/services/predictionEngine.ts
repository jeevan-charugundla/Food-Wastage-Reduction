import { AttendanceRecord, PredictionMode, AdvancedPredictionResult } from '../types';

interface PredictionParams {
  history: AttendanceRecord[];
  targetDate: string; // YYYY-MM-DD
  mode: PredictionMode;
  isSpecialEvent: boolean;
}

export const runPredictionAlgorithm = ({
  history,
  targetDate,
  mode,
  isSpecialEvent
}: PredictionParams): AdvancedPredictionResult => {
  
  // Sort history by date descending (newest first)
  const sortedHistory = [...history].sort((a, b) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  // Parse YYYY-MM-DD strictly to local time to avoid UTC shifts
  const [y, m, d] = targetDate.split('-').map(Number);
  const dateObj = new Date(y, m - 1, d);
  const targetDay = dateObj.getDay();
  
  const isWeekend = targetDay === 0 || targetDay === 6;

  let prediction = 0;
  let logic = "";
  let confidence: 'LOW' | 'MEDIUM' | 'HIGH' = 'MEDIUM';

  // --- ALGORITHM SELECTION ---

  // 1. BASIC PREDICTION (Last 7 days avg)
  if (mode === PredictionMode.BASIC) {
    const last7 = sortedHistory.slice(0, 7);
    if (last7.length === 0) {
        return { predicted_attendance: 0, recommended_food: 0, confidence: 'LOW', logic_used: 'Insufficient data', mode };
    }
    const sum = last7.reduce((acc, curr) => acc + curr.actual_count, 0);
    const avg = sum / last7.length;

    prediction = avg;
    logic = "Average of last 7 days";

    if (isWeekend) {
      prediction += avg * 0.10; // +10% weekend
      logic += " + 10% weekend adjustment";
    }
    if (isSpecialEvent) {
      prediction += avg * 0.05; // +5% special event
      logic += " + 5% special event adjustment";
    }
  }

  // 2. WEIGHTED TREND (Weighted avg of last 5 days)
  else if (mode === PredictionMode.WEIGHTED) {
    const last5 = sortedHistory.slice(0, 5);
    const weights = [0.30, 0.25, 0.20, 0.15, 0.10]; // Newest to oldest
    
    // Fallback if less than 5 days
    if (last5.length < 5) {
       // Fallback to basic logic inline or recursion
       const sum = last5.reduce((acc, c) => acc + c.actual_count, 0);
       prediction = sum / last5.length;
       confidence = 'LOW';
       logic = "Weighted (Fallback due to insufficient data)";
    } else {
        prediction = last5.reduce((acc, curr, idx) => acc + (curr.actual_count * weights[idx]), 0);
        logic = "Weighted average (recent days have higher impact)";
        confidence = 'HIGH';
    }

    if (isWeekend) {
        prediction += 10; // Flat addition
        logic += " + weekend buffer";
    }
  }

  // 3. ADVANCED (Trend detection + Seasonal)
  else if (mode === PredictionMode.ADVANCED) {
    const last14 = sortedHistory.slice(0, 14);
    if (last14.length < 7) {
        // Fallback
        const sum = last14.reduce((acc, c) => acc + c.actual_count, 0);
        prediction = sum / last14.length;
        confidence = 'LOW';
        logic = "Advanced (Fallback)";
    } else {
        // Simple Trend Detection: Compare Avg(Last 3) vs Avg(Prev 3)
        const recent3 = last14.slice(0, 3);
        const prev3 = last14.slice(3, 6);
        
        const avgRecent = recent3.reduce((a, b) => a + b.actual_count, 0) / recent3.length;
        const avgPrev = prev3.reduce((a, b) => a + b.actual_count, 0) / prev3.length;
        
        const trendDiff = avgRecent - avgPrev;
        
        // Base prediction is Weighted Trend
        const last5 = sortedHistory.slice(0, 5);
        const weights = [0.3, 0.25, 0.2, 0.15, 0.1];
        let basePred = last5.reduce((acc, curr, idx) => acc + (curr.actual_count * (weights[idx] || 0)), 0);
        
        prediction = basePred;
        logic = "Trend Analysis";

        if (trendDiff > 5) {
            prediction += basePred * 0.05; // Rising trend
            logic += ": Rising Trend detected (+5%)";
        } else if (trendDiff < -5) {
            prediction -= basePred * 0.03; // Falling trend
            logic += ": Falling Trend detected (-3%)";
        } else {
            logic += ": Stable Trend";
        }

        prediction += basePred * 0.05; // Always add safety buffer in Advanced mode
        logic += " + 5% AI safety buffer";
        confidence = 'HIGH';
    }
  }

  // Final rounding and Food Calculation
  const finalPrediction = Math.round(prediction);
  
  // Food Recommendation: Prediction * 1.05 safety buffer, rounded up to nearest 5
  const rawFood = finalPrediction * 1.05;
  const recommendedFood = Math.ceil(rawFood / 5) * 5;

  return {
    predicted_attendance: finalPrediction,
    recommended_food: recommendedFood,
    confidence,
    logic_used: logic,
    mode
  };
};