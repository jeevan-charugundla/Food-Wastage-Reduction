import { AttendanceRecord, FoodStatus, Pickup, PickupStatus, SurplusFood, User, UserRole, StudentConfirmation, MealStatus, MealType, Badge, StudentVote, VoteOption, NgoCapacity, NgoReliability, DigitalReceipt, DailyMenu, Poll, PollVote } from '../types';

// Constants for LocalStorage keys
const USERS_KEY = 'sfr_users';
const ATTENDANCE_KEY = 'sfr_attendance';
const FOOD_KEY = 'sfr_food';
const PICKUPS_KEY = 'sfr_pickups';
const CONFIRMATIONS_KEY = 'sfr_confirmations';
const VOTES_KEY = 'sfr_votes';
const BADGES_KEY = 'sfr_badges';
const NGO_CAPACITY_KEY = 'sfr_ngo_capacity';
const NGO_RELIABILITY_KEY = 'sfr_ngo_reliability';
const RECEIPTS_KEY = 'sfr_receipts';
const MENU_KEY = 'sfr_menus';
const POLLS_KEY = 'sfr_polls';
const POLL_VOTES_KEY = 'sfr_poll_votes';

// Helper to get today - n days
const getPastDate = (days: number) => {
  const d = new Date();
  d.setDate(d.getDate() - days);
  return d.toISOString().split('T')[0];
};

// INITIAL SEED DATA
const SEED_USERS: User[] = [
  {
    id: "admin-001",
    name: "VJIT Hostel",
    email: "admin@hostel.com",
    role: UserRole.ADMIN,
    phone: "9876543210",
    location: "Hyderabad, Area 51",
    created_at: new Date().toISOString()
  },
  {
    id: "ngo-001",
    name: "Helping Hands NGO",
    email: "ngo@help.org",
    role: UserRole.NGO,
    phone: "9123456789",
    location: "Hyderabad, Area 52",
    created_at: new Date().toISOString()
  },
  {
    id: "student-001",
    name: "Rahul Student",
    email: "student@college.edu",
    role: UserRole.STUDENT,
    phone: "9988776655",
    location: "Hostel Block A",
    created_at: new Date().toISOString()
  }
];

// Generate 30 days of attendance history for ADMIN view
const generateAttendanceHistory = (): AttendanceRecord[] => {
  const records: AttendanceRecord[] = [];
  const baseAttendance = 230;
  
  for (let i = 1; i <= 30; i++) {
    const date = getPastDate(i);
    const dayOfWeek = new Date(date).getDay();
    const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
    const trendFactor = (30 - i) * 0.5; 
    const weekendFactor = isWeekend ? -15 : 0;
    const noise = Math.floor(Math.random() * 20) - 10;
    const actual = Math.floor(baseAttendance + trendFactor + weekendFactor + noise);
    
    records.push({
      id: i,
      admin_id: "admin-001",
      date: date,
      expected_count: baseAttendance + 5,
      actual_count: actual
    });
  }
  return records;
};

const SEED_ATTENDANCE: AttendanceRecord[] = generateAttendanceHistory();

const SEED_FOOD: SurplusFood[] = [
  {
    id: 1,
    admin_id: "admin-001",
    food_name: "Rice & Curry",
    quantity: 50,
    cooked_time: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
    expiry_time: new Date(Date.now() + 1000 * 60 * 60 * 2).toISOString(), // Expiring in 2 hours
    status: FoodStatus.AVAILABLE
  },
];

const SEED_PICKUPS: Pickup[] = [
  {
    id: 101,
    food_id: 999, // Mock ID for history
    ngo_id: "ngo-001",
    pickup_status: PickupStatus.DELIVERED,
    proof_url: "https://via.placeholder.com/150",
    proof_uploaded_at: getPastDate(1),
    food: {
      id: 999,
      admin_id: "admin-001",
      food_name: "Veg Biryani",
      quantity: 40,
      cooked_time: getPastDate(1),
      expiry_time: getPastDate(1),
      status: FoodStatus.ACCEPTED,
      location: "Hyderabad, Area 51"
    }
  }
];

const SEED_RECEIPTS: DigitalReceipt[] = [
  {
    id: "NGO-202403-0101",
    pickup_id: 101,
    ngo_id: "ngo-001",
    ngo_name: "Helping Hands NGO",
    admin_id: "admin-001",
    donor_name: "VJIT Hostel",
    food_name: "Veg Biryani",
    quantity: 40,
    pickup_location: "Hyderabad, Area 51",
    pickup_time: new Date().toISOString(),
    generated_at: new Date().toISOString(),
    verification_status: 'VERIFIED'
  }
];

const SEED_NGO_CAPACITY: NgoCapacity[] = [
  {
    ngo_id: "ngo-001",
    date: getPastDate(0),
    max_capacity: 150,
    remaining_capacity: 150,
    volunteers_available: 5
  }
];

const SEED_NGO_RELIABILITY: NgoReliability[] = [
  {
    score: 92,
    on_time_percentage: 95,
    missed_pickups: 1
  }
];

// Generate Student Confirmations
const generateStudentConfirmations = (): StudentConfirmation[] => {
  const confs: StudentConfirmation[] = [];
  const studentId = "student-001";
  const today = getPastDate(0);

  // Generate history for last 7 days for the logged-in student
  for (let i = 7; i > 0; i--) {
    const date = getPastDate(i);
    // Breakfast
    confs.push({ id: Number(`${i}1`), student_id: studentId, date, meal_type: MealType.BREAKFAST, status: MealStatus.EATING, timestamp: date });
    // Lunch - maybe skipped one
    confs.push({ id: Number(`${i}2`), student_id: studentId, date, meal_type: MealType.LUNCH, status: i === 3 ? MealStatus.NOT_EATING : MealStatus.EATING, timestamp: date });
    // Dinner
    confs.push({ id: Number(`${i}3`), student_id: studentId, date, meal_type: MealType.DINNER, status: MealStatus.EATING, timestamp: date });
  }

  // Today's Data (Initial State)
  confs.push({ id: 901, student_id: studentId, date: today, meal_type: MealType.BREAKFAST, status: MealStatus.EATING, timestamp: new Date().toISOString() });
  confs.push({ id: 902, student_id: studentId, date: today, meal_type: MealType.LUNCH, status: MealStatus.PENDING, timestamp: new Date().toISOString() });
  confs.push({ id: 903, student_id: studentId, date: today, meal_type: MealType.DINNER, status: MealStatus.PENDING, timestamp: new Date().toISOString() });

  return confs;
};

const SEED_CONFIRMATIONS: StudentConfirmation[] = generateStudentConfirmations();

// Generate Votes for TODAY
const generateSeedVotes = (): StudentVote[] => {
  const votes: StudentVote[] = [];
  const today = getPastDate(0);
  
  // Requirement: 140 YES, 35 NO, 25 MAYBE
  const counts = { [VoteOption.YES]: 140, [VoteOption.NO]: 35, [VoteOption.MAYBE]: 25 };
  let idCounter = 1;

  Object.entries(counts).forEach(([option, count]) => {
    for (let i = 0; i < count; i++) {
      votes.push({
        id: idCounter++,
        student_id: `mock-student-${idCounter}`,
        date: today,
        vote: option as VoteOption,
        voted_at: new Date().toISOString()
      });
    }
  });

  return votes;
};

const SEED_VOTES: StudentVote[] = generateSeedVotes();

const SEED_MENU: DailyMenu[] = [
  {
    date: getPastDate(0),
    breakfast: "Idli, Vada, Sambar, Coconut Chutney",
    lunch: "Rice, Dal Fry, Mixed Veg Curry, Curd, Pickle",
    dinner: "Chapati, Paneer Butter Masala, Rice, Salad"
  }
];

const SEED_BADGES: Badge[] = [
  {
    id: 'b1',
    name: 'Honest Eater',
    description: 'Confirmed accurately for 7 days straight',
    icon: 'ShieldCheck',
    awarded_at: getPastDate(2)
  },
  {
    id: 'b2',
    name: 'Food Saver',
    description: 'Opted out of 10 meals ahead of time',
    icon: 'Leaf',
    awarded_at: getPastDate(5)
  }
];

// Seed Poll Data
const SEED_POLLS: Poll[] = [
  {
    id: 'poll-001',
    question: 'What should be the special for Sunday Lunch?',
    active: true,
    options: [
      { id: 'opt1', label: 'Chicken Biryani', count: 45 },
      { id: 'opt2', label: 'Veg Pulao & Paneer', count: 22 },
      { id: 'opt3', label: 'Fried Rice & Manchurian', count: 38 }
    ]
  }
];

const SEED_POLL_VOTES: PollVote[] = [];

// Initialize DB
const initDb = () => {
  if (!localStorage.getItem(USERS_KEY)) localStorage.setItem(USERS_KEY, JSON.stringify(SEED_USERS));
  if (!localStorage.getItem(ATTENDANCE_KEY)) localStorage.setItem(ATTENDANCE_KEY, JSON.stringify(SEED_ATTENDANCE));
  if (!localStorage.getItem(FOOD_KEY)) localStorage.setItem(FOOD_KEY, JSON.stringify(SEED_FOOD));
  if (!localStorage.getItem(PICKUPS_KEY)) localStorage.setItem(PICKUPS_KEY, JSON.stringify(SEED_PICKUPS));
  if (!localStorage.getItem(CONFIRMATIONS_KEY)) localStorage.setItem(CONFIRMATIONS_KEY, JSON.stringify(SEED_CONFIRMATIONS));
  if (!localStorage.getItem(VOTES_KEY)) localStorage.setItem(VOTES_KEY, JSON.stringify(SEED_VOTES));
  if (!localStorage.getItem(BADGES_KEY)) localStorage.setItem(BADGES_KEY, JSON.stringify(SEED_BADGES));
  if (!localStorage.getItem(NGO_CAPACITY_KEY)) localStorage.setItem(NGO_CAPACITY_KEY, JSON.stringify(SEED_NGO_CAPACITY));
  if (!localStorage.getItem(NGO_RELIABILITY_KEY)) localStorage.setItem(NGO_RELIABILITY_KEY, JSON.stringify(SEED_NGO_RELIABILITY));
  if (!localStorage.getItem(RECEIPTS_KEY)) localStorage.setItem(RECEIPTS_KEY, JSON.stringify(SEED_RECEIPTS));
  if (!localStorage.getItem(MENU_KEY)) localStorage.setItem(MENU_KEY, JSON.stringify(SEED_MENU));
  if (!localStorage.getItem(POLLS_KEY)) localStorage.setItem(POLLS_KEY, JSON.stringify(SEED_POLLS));
  if (!localStorage.getItem(POLL_VOTES_KEY)) localStorage.setItem(POLL_VOTES_KEY, JSON.stringify(SEED_POLL_VOTES));
};

initDb();

// DB Accessors
export const db = {
  getUsers: (): User[] => JSON.parse(localStorage.getItem(USERS_KEY) || '[]'),
  getAttendance: (): AttendanceRecord[] => JSON.parse(localStorage.getItem(ATTENDANCE_KEY) || '[]'),
  getFood: (): SurplusFood[] => JSON.parse(localStorage.getItem(FOOD_KEY) || '[]'),
  getPickups: (): Pickup[] => JSON.parse(localStorage.getItem(PICKUPS_KEY) || '[]'),
  getReceipts: (): DigitalReceipt[] => JSON.parse(localStorage.getItem(RECEIPTS_KEY) || '[]'),
  getConfirmations: (): StudentConfirmation[] => JSON.parse(localStorage.getItem(CONFIRMATIONS_KEY) || '[]'),
  getVotes: (): StudentVote[] => JSON.parse(localStorage.getItem(VOTES_KEY) || '[]'),
  getMenu: (): DailyMenu[] => JSON.parse(localStorage.getItem(MENU_KEY) || '[]'),
  getBadges: (): Badge[] => JSON.parse(localStorage.getItem(BADGES_KEY) || '[]'),
  getNgoCapacity: (): NgoCapacity[] => JSON.parse(localStorage.getItem(NGO_CAPACITY_KEY) || '[]'),
  getNgoReliability: (): NgoReliability[] => JSON.parse(localStorage.getItem(NGO_RELIABILITY_KEY) || '[]'),
  getPolls: (): Poll[] => JSON.parse(localStorage.getItem(POLLS_KEY) || '[]'),
  getPollVotes: (): PollVote[] => JSON.parse(localStorage.getItem(POLL_VOTES_KEY) || '[]'),
  
  saveUsers: (data: User[]) => localStorage.setItem(USERS_KEY, JSON.stringify(data)),
  saveAttendance: (data: AttendanceRecord[]) => localStorage.setItem(ATTENDANCE_KEY, JSON.stringify(data)),
  saveFood: (data: SurplusFood[]) => localStorage.setItem(FOOD_KEY, JSON.stringify(data)),
  savePickups: (data: Pickup[]) => localStorage.setItem(PICKUPS_KEY, JSON.stringify(data)),
  saveReceipts: (data: DigitalReceipt[]) => localStorage.setItem(RECEIPTS_KEY, JSON.stringify(data)),
  saveConfirmations: (data: StudentConfirmation[]) => localStorage.setItem(CONFIRMATIONS_KEY, JSON.stringify(data)),
  saveVotes: (data: StudentVote[]) => localStorage.setItem(VOTES_KEY, JSON.stringify(data)),
  saveBadges: (data: Badge[]) => localStorage.setItem(BADGES_KEY, JSON.stringify(data)),
  saveNgoCapacity: (data: NgoCapacity[]) => localStorage.setItem(NGO_CAPACITY_KEY, JSON.stringify(data)),
  saveNgoReliability: (data: NgoReliability[]) => localStorage.setItem(NGO_RELIABILITY_KEY, JSON.stringify(data)),
  savePolls: (data: Poll[]) => localStorage.setItem(POLLS_KEY, JSON.stringify(data)),
  savePollVotes: (data: PollVote[]) => localStorage.setItem(POLL_VOTES_KEY, JSON.stringify(data)),
};