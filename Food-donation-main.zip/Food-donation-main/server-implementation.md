# Backend Implementation Reference

For a full production deployment, the logic currently in `services/mockDb.ts` and `services/api.ts` should be moved to a Node.js Express server.

Below is the reference code for `server/index.js` and `server/routes.js`.

## 1. Setup
`npm init -y`
`npm install express cors pg dotenv`

## 2. Server Entry (`server/index.js`)
```javascript
const express = require('express');
const cors = require('cors');
const routes = require('./routes');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

app.use('/api', routes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
```

## 3. Routes & Logic (`server/routes.js`)
```javascript
const express = require('express');
const router = express.Router();
const { Pool } = require('pg');

// DB Connection
const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

// Auth
router.post('/auth/login', async (req, res) => {
  const { email } = req.body;
  const result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
  if (result.rows.length === 0) return res.status(404).json({ error: "User not found" });
  res.json(result.rows[0]);
});

// Attendance Prediction
router.get('/attendance/history/:adminId', async (req, res) => {
  const { adminId } = req.params;
  const result = await pool.query('SELECT * FROM attendance_history WHERE admin_id = $1 ORDER BY date DESC', [adminId]);
  res.json(result.rows);
});

router.post('/attendance/predict', async (req, res) => {
  const { adminId } = req.body;
  // Get last 7 days
  const history = await pool.query(
    'SELECT actual_count FROM attendance_history WHERE admin_id = $1 ORDER BY date DESC LIMIT 7', 
    [adminId]
  );
  
  const counts = history.rows.map(r => r.actual_count);
  if (counts.length === 0) return res.json({ predicted: 0 });

  const avg = counts.reduce((a, b) => a + b, 0) / counts.length;
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const isWeekend = tomorrow.getDay() === 0 || tomorrow.getDay() === 6;
  
  let prediction = avg;
  if (isWeekend) prediction *= 1.10; // +10%

  res.json({
    predicted_count: Math.round(prediction),
    recommended_food: Math.round(prediction) + 10
  });
});

// Food Management
router.get('/food/available', async (req, res) => {
  const result = await pool.query(`
    SELECT sf.*, u.name as admin_name, u.location 
    FROM surplus_food sf 
    JOIN users u ON sf.admin_id = u.id 
    WHERE sf.status = 'AVAILABLE' AND sf.expiry_time > NOW()
  `);
  res.json(result.rows);
});

router.post('/food/add', async (req, res) => {
  const { admin_id, food_name, quantity, cooked_time, expiry_time } = req.body;
  const result = await pool.query(
    'INSERT INTO surplus_food (admin_id, food_name, quantity, cooked_time, expiry_time, status) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *',
    [admin_id, food_name, quantity, cooked_time, expiry_time, 'AVAILABLE']
  );
  res.json(result.rows[0]);
});

// Pickups
router.post('/pickup/accept', async (req, res) => {
  const { foodId, ngoId } = req.body;
  // Transaction to ensure atomicity
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query('UPDATE surplus_food SET status = $1 WHERE id = $2', ['ACCEPTED', foodId]);
    const resPickup = await client.query(
      'INSERT INTO pickups (food_id, ngo_id, pickup_status) VALUES ($1, $2, $3) RETURNING *',
      [foodId, ngoId, 'PENDING']
    );
    await client.query('COMMIT');
    res.json(resPickup.rows[0]);
  } catch (e) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: e.message });
  } finally {
    client.release();
  }
});

module.exports = router;
```
